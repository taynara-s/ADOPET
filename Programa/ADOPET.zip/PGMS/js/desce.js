function descer() {
	document.body.scrollBottom = 0;
	document.documentElement.scrollBottom = 0;
}